
module.exports = {
  // domain: 'http://hasonhaivan.vn',
  domain: 'http://hai-van.local',
  cache: 'no-cache',
  errorHttp: 'Lỗi hệ thống. Vui lòng liên hệ với bộ phận Kỹ Thuật.'
}
